from distutils.core import setup

setup(
    name = 'nester',
    version = '1.2.0',
    py_modules = ['nester'],
    author = 'me',
    author_email = "nguyenjames0404@yahoo.com",
    url = "http://www.linkedin.com/nguyenjames0404",
    description = "Print nested lists"
)