
# Goes through a list, and if there are any nested lists, prints items individually
def print_lol(some_list, indentation = 0):
    for item in some_list:
        if isinstance(item, list):
            print_lol(item, indentation + 1) #recursive
        else:
            for tab_stop in range(indentation):
                print("\t", end='')
            print(item)